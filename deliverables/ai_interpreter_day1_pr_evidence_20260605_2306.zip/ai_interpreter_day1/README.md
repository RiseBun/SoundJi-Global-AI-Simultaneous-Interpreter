# AI 同声传译助手

## 项目简介

AI 同声传译助手是一个面向技术分享、网课和跨语言会议场景的 P0 mock proof chain。当前版本用于证明“术语可控、状态可追踪、证据可复盘”的最小工程闭环，不是生产级同传应用。

当前 P0 闭环：

```text
SampleStream
-> ASREvent partial/final
-> TermEntry / TermHit
-> TimelineItem
-> Markdown / JSON ExportArtifact
```

## 议题方向

- AI 同声传译助手
- 语音交互与实时字幕状态
- 术语表/热词约束
- AI-native 工程证据链
- XEngineer / ZGC Vibe Coding 项目实践

## 核心功能

- 使用固定英文技术分享 mock stream 模拟同传输入。
- 使用 partial/final ASR 事件区分不稳定字幕和稳定字幕。
- 使用术语表约束关键技术词，如 RAG、API、vector database、embedding、latency。
- 生成双语时间轴，记录英文原文、中文译文、时间范围和术语命中。
- 导出 Markdown transcript 和 JSON transcript。
- 覆盖 ASR、translation、export、glossary 四类 fallback。

## 技术栈和第三方依赖

当前 P0 版本只使用：

- Python 标准库
- Markdown 文档
- JSON mock 数据

当前未使用：

- React
- FastAPI
- OpenAI SDK
- LangChain
- Tailwind
- Whisper / FunASR / Vosk
- 数据库
- 真实会议平台 SDK

如后续接入任何第三方库、框架、模型 SDK 或历史代码片段，必须在 README 和对应 PR 描述中补充依赖来源、用途和原创功能边界。

## 原创功能说明

本项目当前原创部分是 P0 工程证据链设计和 mock demo 闭环，而不是某个真实 ASR 或翻译模型能力。

原创设计重点：

- 将“AI 同传”收敛为术语约束、字幕状态、时间轴和导出四个可验证能力。
- 用 `partial -> final` 事件表达实时字幕不稳定性，避免把临时识别结果直接写入最终复盘。
- 用术语命中记录证明不是简单的 ASR + 翻译 API 壳。
- 用 fallback 明确 ASR、翻译、导出、术语导入失败时的降级边界。
- 用 Markdown/JSON transcript 形成可交接、可复盘 artifact。

## 本地运行方式

从项目目录运行：

```powershell
cd "G:\TRAE_Code\06_Vibe_Coding_ZGC\xengineer_demo"
python ".\scripts\validate_ai_interpreter_mock_data.py"
python ".\scripts\run_ai_interpreter_mock_demo.py"
```

或从任意目录运行绝对路径：

```powershell
python "G:\TRAE_Code\06_Vibe_Coding_ZGC\xengineer_demo\scripts\validate_ai_interpreter_mock_data.py"
python "G:\TRAE_Code\06_Vibe_Coding_ZGC\xengineer_demo\scripts\run_ai_interpreter_mock_demo.py"
```

预期输出：

```text
AI interpreter mock data validation passed.
Summary: partials=10, finals=10, terms=10, timeline_items=10, fallbacks=asr/translation/export/glossary

AI interpreter mock demo transcript generated.
Summary: finals=10, glossary_entries=10, term_hits=13, ... optional_revision_demo_exists=true
```

## 测试方式

1. 运行 mock 数据校验脚本：

```powershell
python "G:\TRAE_Code\06_Vibe_Coding_ZGC\xengineer_demo\scripts\validate_ai_interpreter_mock_data.py"
```

验收点：

- 四个 JSON 文件存在且可解析。
- partial 和 final 事件数量一致。
- 时间轴条数与 final 事件一致。
- 必需术语存在。
- fallback 覆盖 ASR、translation、export、glossary。

2. 运行 mock demo runner：

```powershell
python "G:\TRAE_Code\06_Vibe_Coding_ZGC\xengineer_demo\scripts\run_ai_interpreter_mock_demo.py"
```

验收点：

- 生成 `outputs/ai_interpreter/transcript.md`。
- 生成 `outputs/ai_interpreter/transcript.json`。
- summary 显示 `finals=10`、`glossary_entries=10`、`term_hits=13`。
- P2 revision demo 只在 summary 标注，不进入主 timeline。

## 项目结构

```text
xengineer_demo/
  README.md
  context.txt
  docs/
    ai_interpreter/
      00_project_handoff.md
      01_technical_proposal.md
      02_architecture_design.md
      03_implementation_design.md
      04_mvp_analysis.md
      05_day1_pr_commit_evidence.md
  mock_data/
    ai_interpreter/
      sample_stream.json
      term_glossary.json
      expected_timeline.json
      fallback_examples.json
  scripts/
    validate_ai_interpreter_mock_data.py
    run_ai_interpreter_mock_demo.py
  outputs/
    ai_interpreter/
      transcript.md
      transcript.json
  deliverables/
    ai_interpreter_day1_pr_evidence_*.zip
```

## Demo 视频链接

待补充。

当前可复现证据是本地 runner 和 transcript 输出。正式提交前建议录制 1-3 分钟 demo，展示：

1. 打开 README。
2. 运行 mock 数据校验。
3. 运行 mock demo runner。
4. 打开 `transcript.md` 和 `transcript.json`。
5. 说明当前是 P0 mock proof chain，不是生产同传。

## 团队分工

当前记录用于个人 Day 1 PR/commit 证据包。如后续多人协作，建议补充分工：

- Product / Planner：赛题理解、用户痛点、MVP 边界。
- Architecture：XEngineer 六层架构、mock/real adapter 边界。
- Implementation：mock 数据、校验脚本、runner。
- QA / Review：验收命令、红线审查、交接包核验。
- Demo：视频录制、讲解脚本、README 更新。

## PR 与 commit 规范说明

当前目录不是 git 仓库，因此本地文件不能声称已经创建真实 GitHub/Gitee PR 或 commit。

本项目提供的是 Day 1 PR/commit 证据包，真实提交时应按小 PR 分步提交：

```text
PR 1: 初始化 AI 同声传译助手 Day 1 工程证据包
commit 1: docs: add ai interpreter README
commit 2: docs: add technical proposal architecture implementation mvp docs
commit 3: data: add p0 mock stream glossary timeline fallback examples
commit 4: test: add mock data validation script
commit 5: feat: add p0 mock runner and transcript artifacts
commit 6: docs: add day1 pr commit evidence record
```

## 已知限制

- 当前是 P0 mock proof chain，不是生产应用。
- 未接真实 ASR。
- 未接真实 LLM 或翻译模型。
- 未接真实会议平台。
- 未实现 TTS、多语种、API、数据库或前端。
- 未证明生产级低延迟。
- 未创建真实 PR 或 commit；真实仓库提交时必须使用比赛规定时间内的 commit 和 PR 记录。
- 如复用历史代码，必须在 PR 描述中注明来源。
